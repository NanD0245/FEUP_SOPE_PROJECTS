#ifndef _DELAY_H
#define _DELAY_H 1
extern int delay;
#endif // _DELAY_H
